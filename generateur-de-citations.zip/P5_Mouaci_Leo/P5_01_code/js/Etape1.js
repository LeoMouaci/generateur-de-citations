// Toutes les données
let start = [
    "« La seule façon",
    "« La meilleure des façons",
    "« Le meilleur moyen",
    "« La meilleure des manières",
    "« L'hacharnement",
    "« La pire des façon",
    "« Le pire moyen",
    "« La pire des manières",
    "« L'unique méthode",
    "« L'unique moyen"
];
let middle = [
    " pour réussir,",
    " d'être heureux,",
    " de vivre,",
    " d'y arriver,",
    " d'aller au bout de ses rêves,"
];
let end = [
    " c'est d'aimer ce que vous faites. »",
    " ne dépend que de vous. »",
    " c'est de s'obstiner. »",
    " c'est simple, il n'y en a pas. »",
    " n'apporte rien. »"
];


/* Fonction permettant de chercher à l'intérieur d'un array (tableau) un nombre aléatoire */
// Math.random : cherche quelque chose entre 0 et 1. 
// Math.floor : arrandi à zéro. 
// array.length = la longueur du tableau choisi à la place du mot "array" donc ça va chercher entre 0 jusqu'à la fin du tableau. 

const citationAleatoire = (array) => {
    return array[Math.floor(Math.random() * array.length)];
}

// Assemblage des mots aléatoires 
console.log(citationAleatoire(start) + citationAleatoire(middle) + citationAleatoire(end));
