// Toutes les données
const allPhrases = {
    "philosophie": {
        "start": [
            "« La seule façon",
            "« La meilleure des façons",
            "« Le meilleur moyen",
            "« La meilleure des manières",
            "« L'hacharnement",
            "« La pire des façon",
            "« Le pire moyen",
            "« La pire des manières",
            "« L'unique méthode",
            "« L'unique moyen"
        ],
        "middle": [
            " pour réussir,",
            " d'être heureux,",
            " de vivre,",
            " d'y arriver,",
            " d'aller au bout de ses rêves,"
        ],
        "end": [
            " c'est d'aimer ce que vous faites. »",
            " ne dépend que de vous. »",
            " c'est de s'obstiner. »",
            " c'est simple, il n'y en a pas. »",
            " n'apporte rien. »"
        ]
    },
    "Kaamelott": {
        "start": [
            "Au printemps, ",
            "Dans le Languedoc, ils m'appellent Provençal ",
            "Dans la vie, j'avais deux ennemis : ",
            "J'voudrais pas faire ma raclette, ",
            "Si on faisait le coup du bouclier humain... ",
            "Si Joseph d'Arimathie a pas été trop con, ",
            "Putain, ",
            "C’est pour ça ",
            "Faut arrêter ces conneries de nord et de sud, ",
            "Une fois, à une exécution, "
        ],
        "middle": [
            "j’aime bien pisser du haut des remparts au lever du soleil..., ",
            "le vocabulaire et les épinards, ",
            "par exemple, Sire, Léodagan et moi on fait semblant de vous prendre en otage ", "vous pouvez être sûr que le Graal, ",
            "c’est un vrai piège à cons c’t’histoire-là, ",
            "une fois pour toute, le nord, suivant comment on est tourné, "
        ],
        "end": [
            "c'est pas faux !",
            "y’a une belle vue !",
            "mais c'est moi qui m'suis gouré en disant mon nom.",
            "enfin tous les chiffres impairs jusqu'à 22.",
            "on vous met une dague sous le cou et on traverse le camp adverse en gueulant : Bougez pas, bougez pas ou on bute le roi!",
            "c'est un bocal à anchois.",
            "en plein dans sa mouille !",
            "j’lis jamais rien.",
            "en plus j’sais pas lire.",
            "je m'approche d'une fille. Pour rigoler, je lui fais : « Vous êtes de la famille du pendu ? »"
        ]
    }
}


// Fonction permettant de chercher à l'intérieur d'un array (tableau) un nombre aléatoire 
const citationAleatoire = (array) => {
    return array[Math.floor(Math.random() * array.length)];
}

// Assemblage des mots aléatoires 
const citationKaamelott = () => {
    return citationAleatoire(allPhrases.Kaamelott.start) + citationAleatoire(allPhrases.Kaamelott.middle) + citationAleatoire(allPhrases.Kaamelott.end);
}

const citationPhilosophie = () => {
    return citationAleatoire(allPhrases.philosophie.start) + citationAleatoire(allPhrases.philosophie.middle) + citationAleatoire(allPhrases.philosophie.end);
}



// Consigne du programme : 
console.log("Bienvenue dans le générateur des citations !\n\n")
console.log("(1) : Générer des citations sur Kaamelott")
console.log("(2) : Générer des citations philosophiques")
console.log("(0) : Quitter le programme")

let typeCitation = ""

// Programme en boucle qui continue temps que le prompt "typeCitation" n'est pas égal en types ou en valeur à "0" pour quitter ou "null" pour annuler. 
while (typeCitation !== '0' && typeCitation !== null) {

    typeCitation = prompt('Bonjour, quel type de citations souhaitez-vous ? (Tapez (1) pour "Kaamelott", tapez (2) pour "Philosophie, tapez (0) pour quitter").');

    switch (typeCitation) {
        case '1':
            console.log('\nVous avez choisi les citations de Kaamelott ;');
            var nombreCitations = prompt('Combien de citations de Kaamelott souhaitez-vous ? Tapez un chiffre entre (1) et (5).');
            if ((nombreCitations >= 1) && (nombreCitations <= 5)) {
                for (var i = 1; i <= nombreCitations; i++) {
                    console.log(citationKaamelott())
                }

            } else
                console.log('Vous avez écrit (' + nombreCitations + '), merci de choisir un nombre entre (1) et (5).');
            break;

        case '2':
            console.log('\nVous avez choisi les citations philosophiques ;');
            var nombreCitations = prompt('Combien de citations philosophiques souhaitez-vous ? Tapez un chiffre entre (1) et (5).');
            if ((nombreCitations >= 1) && (nombreCitations <= 5)) {
                for (var i = 1; i <= nombreCitations; i++) {
                    console.log(citationPhilosophie())
                }

            } else
                console.log('Vous avez écrit (' + nombreCitations + '), merci de choisir un nombre entre (1) et (5).');
            break;

        case '0':
        case null:
            console.log('\nVous avez choisi de quitter, merci et au plaisir de vous revoir !');
            break;

        default:
            console.log('\nVous avez écrit (' + typeCitation + '), merci de choisir un type de citation avec (1) ou (2)');
            break;
    }
}
